import {circle,rectangle,cylinder} from './area.js' // importing the modules for calculating area of different shapes...@@~!
import{outputArray} from './FilteredArray' // imported another js file to perform 9th question
//  QUESTION 01:  Given this array: `[3,62,234,7,23,74,23,76,92]`, Using arrow function, create an array of the numbers greater than `70`.

const numArray = [3, 62, 234, 7, 23, 74, 23, 76, 92]; // decalaration of array.
const result = numArray.filter(numArray => numArray > 70);
console.log("Q1 :" + result);

  /*QUESTION 02:<ul>
  <li data-time="5:17">Flexbox Video</li>
  <li data-time="8:22">Flexbox Video</li>
  <li data-time="3:34">Redux Video</li>
  <li data-time="5:23">Flexbox Video</li>
  <li data-time="7:12">Flexbox Video</li>
  <li data-time="7:24">Redux Video</li>
  <li data-time="6:46">Flexbox Video</li>
  <li data-time="4:45">Flexbox Video</li>
  <li data-time="4:40">Flexbox Video</li>
  <li data-time="7:58">Redux Video</li>
  <li data-time="11:51">Flexbox Video</li>
  <li data-time="9:13">Flexbox Video</li>
  <li data-time="5:50">Flexbox Video</li>
  <li data-time="5:52">Redux Video</li>
  <li data-time="5:49">Flexbox Video</li>
  <li data-time="8:57">Flexbox Video</li>
  <li data-time="11:29">Flexbox Video</li>
  <li data-time="3:07">Flexbox Video</li>
  <li data-time="5:59">Redux Video</li>
  <li data-time="3:31">Flexbox Video</li>
</ul>

a. Select all the list items on the page and convert to array.
b. Filter for only the elements that contain the word 'flexbox'
c. Map down to a list of time strings
d. Map to an array of seconds
e. Reduce to get total using .filter and .map
  */

  // Select all the list items on the page and convert to array
  // const items = Array.from(document.querySelectorAll('[data-time]'));
   // console.log(items);
   // Filter for only the elements that contain the word 'Flexbox'
   // const filtered = items.filter(item => item.textContent.includes('Flexbox'));
   // console.log(filtered);
     // map down to a list of time strings
     // const list = items.map(item => item.dataset.time);
     // console.log(list);
     // map to an array of seconds
    // const array =   items.map(timecode => {
    //    const parts = timecode.split(':').map(part => parseFloat(part));
    //    return (parts[0] * 60) + parts[1];
    //  })
    //  console.log(array);
     // reduce to get total
//     const reduced =   items.reduce((runningTotal, seconds) => runningTotal + seconds);
// console.log(reduced);
   //console.log(filtered);


/* QUESTION 03: Create a markup template using string literal

const song = {
 name: 'Dying to live',
 artist: 'Tupac',
 featuring: 'Biggie Smalls'
};
Result:
"<div class="song">
   <p>
     Dying to live — Tupac
     (Featuring Biggie Smalls)
   </p>
 </div>
“
*/
const song = {
 name: 'Dying to live',
 artist: 'Tupac',
 featuring: 'Biggie Smalls'
};
const literal = `<div class="song">
        <p>
            ${song.name} - ${song.artist}
            (Featuring ${song.featuring})
        </p>
    </div>`;

console.log("Q3 : "+literal); // printing the result of literal template

/* QUESTION 04:  Extract all keys inside address object from user object using destructuring ?

const user = {
firstName: ‘Sahil’,
lastName: ‘Dua’,
Address: {
Line1: ‘address line 1’,
Line2: ‘address line 2’,
State: ‘Delhi’,
Pin: 110085,
Country: ‘India’,
City: ‘New Delhi’,
},
phoneNo: 9999999999
} */
const user = {
firstName: 'Sahil',
lastName: 'Dua',
Address: {
Line1: 'address line 1',
Line2: 'address line 2',
State: 'Delhi',
Pin: 110085,
Country: 'India',
City: 'New Delhi',
},
phoneNo: 9999999999
};
let{Line1,Line2,State,Pin,Country,City}=user.Address;
console.log("Q4 : " + Line1,Line2,State,Pin,Country,City);

// QUESTION 05:  Find the possible combinations of a string and store them in a MAP?
var combinations = function (string)
{
    var result = [];
    var loop = function (first,last,prefix) // loop to iterate through the string
    {
        for(var i=first; i<string.length; i++) // loop to check the occurence of the combinations
        {
            var next = prefix+string[i];
            if (last > 0)
                loop(i+1,last-1,next);
            else
                result.push(next);
        }
    }
    for(var i=0; i<string.length; i++)
    {
        loop(0,i,'');
    }
    return result;
}

var resultArray = combinations('abc');
console.log(resultArray);
// let arr = new Map();
// for(let i=0;i<resultArray.lenght;i++)
// {
//   let arr = resultArray[i];
//   if(!arr.has(resultArray)){
//     arr.set(resultArray,1);
//   }else{
//     resultArray.set(resultArray,arr.get(resultArray)+1);
//   }
// }
// //const mappedArray = resultArray.map(item => item) // arrow function
// console.log("Q5 : Mapped Array is : " + arr);

// QUESTION 06:Write a program to implement inheritance upto 3 classes.The Class must  public variables and static functions.
 class Car
 {
   constructor(name)
   {
     this.name = name;
   }
   static color()
   {
     console.log(`Q6 : Mercedes is red in color.`);
   }
   seats()
   {
     console.log(`${this.name} is a 2 seater car.`);
   }
}
class Fiat extends Car // inherited the Car class
{
  seats()
  {
    console.log(`${this.name} is a 4 seater car.`); // method in overrided
  }
}
class Embassador extends Fiat // inherited the Fiat class
{
    seats()
    {
      super.seats(); // it invokes the method from the parent class
      console.log(`${this.name} used by Govt. officials.`);

    }

}
let fiat = new Embassador('Embassador');
console.log(Car.color()); // static method ivoked by class name
console.log(fiat.seats()); // method inherited from parent class


// QUESTION 07: Write a program to implement a class having static functions

class Animal {
  static category() {
    return 'Q7 : Category of animal is returned.';
  }
}

console.log(Animal.category());

// QUESTION 08:Import a module containing the constants and method for calculating area of circle, rectangle, cylinder.

console.log("Q8 : Area of circle with radii(4) is : " + circle(4));
console.log(" Area of rectangle with height(4) and breadth(5) is : " + rectangle(4,5));
console.log(" Area of cylinder with radiius(6) and height(10) is : " + cylinder(6,10));


// QUESTION 09: Import a module for filtering unique elements in an array.
// implemented the array filtering using set as asked in Q4(2) in the FilteredArray.js file and imported it in this index.js as askedd in Q9

console.log("Q9 : " + outputArray); // imported as outputArray in the top of this file

//// QUESTION 10: Write a program to flatten a nested array to single level using arrow functions.
var myArray = [[1, 2],[3, 4, 5], [6, 7, 8, 9]];

const outcome = () => {
  let myNewArray3 = [];
for (var i = 0; i < myArray.length; ++i) {
  for (var j = 0; j < myArray[i].length; ++j)
     var a= myNewArray3.push(myArray[i][j]);
     return a;
}}
console.log(outcome);
