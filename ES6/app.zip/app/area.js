const circle = (radii) => Math.PI*radii*radii;
const rectangle = (length,breadth) => length * breadth;
const cylinder = (radius,height) => ((2*Math.PI*radius*height) + (2*Math.PI*radius*radius));
const mixedArray = [1,1,1,2,2,3,4,5,6,7,8,9,9,0,10,10,12,12,14,14,15,15,17,20,25,30,45]
const outputArray = [...new Set(mixedArray)]


export{circle,rectangle,cylinder,outputArray};
